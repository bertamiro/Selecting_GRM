#############################################################
#                                                           #
#                        - lpattern -                       #
#                                                           #
# An R Package for Selecting genes regulated by methylation #
#                                                           #
#############################################################



MI <- function(x,y,h){
  if(length(x) != length(y))  stop("Different number of samples!")
  M <- length(x) # samples
  aux <- 0
  two.h.square <- 2*h^2

for(i in 1:M){
 tmpx <- x - x[i]
 tmpx <- exp(-tmpx^2/(two.h.square))
 tmpy <- y - y[i]
 tmpy <- exp(-tmpy^2/(two.h.square))
 tmp <- tmpx*tmpy
 aux <- aux + log(M*sum(tmp)/(sum(tmpx)*sum(tmpy)))
 }
aux/M
}

cMI <- function(dataMeth, dataExp, t, h=0.3){
  n <- length(dataMeth)
  if(length(dataExp) != n)  stop("Different number of samples!")
  if(t < 0 | t > 1)  stop("t value is out of range")
  filter <- dataMeth < t
  ss <- sum(filter)
  if(ss != 0){
  x <- dataMeth[filter]
  y <- dataExp[filter]
  aux <- MI(x,y,h)*ss/n
  }
  else{
    aux <- 0
  }
  ss <- sum(!filter)
  if(ss != 0){
  x <- dataMeth[!filter]
  y <- dataExp[!filter]
  aux + MI(x,y,h)*ss/n
  }
  else{
    aux
  }
}

vecCorrs <- function (x, y){
  corrS <- rcorr(x, y, type="spearman")
  corrP <- rcorr(x, y, type="pearson")
  return(unlist(list(rhoS=corrS$r[1,2],rhoP=corrP$r[1,2],
                     pvalS=corrS$P[1,2], pvalP=corrP$P[1,2])))
}

matCorrs <- function (X, Y){
  if ((nrow(X)!=nrow(Y))||(ncol(X)!=ncol(Y))) stop('matrices dimensions do not match')
  corrsList<- matrix(NA, nrow=nrow(X), ncol=4)
  colnames(corrsList) <- c("r (Sp)", "r (Pear)",  "p (Sp)","p (Pear)")
  for (i in 1:nrow(X)){
    corrs<- vecCorrs(X[i,],Y[i,])
    corrsList[i,] <- corrs
  }
  rownames(corrsList) <- rownames(X)
  return(corrsList)
}

distCorrs <- function (x, y){
  distCorr <- dcor(x, y, index=1.0)
  return(unlist(list(distCorr)))
}

matDistCorr <- function (X, Y){
  if ((nrow(X)!=nrow(Y))||(ncol(X)!=ncol(Y))) stop('matrices dimensions do not match')
  distCorrsList<- matrix(NA, nrow=nrow(X), ncol=1)
  colnames(distCorrsList) <- c("DistCor")
  for (i in 1:nrow(X)){
    DistCorr<- distCorrs(X[i,],Y[i,])
    distCorrsList[i,] <- DistCorr
  }
  rownames(distCorrsList) <- rownames(X)
  return(distCorrsList)
}

allCorrs  <- function (x, y){
  corrS <- rcorr(x, y, type="spearman")
  corrP <- rcorr(x, y, type="pearson")
  distCorr <- dcor(x, y, index=1.0)
  return(unlist(list(rhoS=corrS$r[1,2],  rhoP=corrP$r[1,2], distCorr,
                     pvalS=corrS$P[1,2], pvalP=corrP$P[1,2])))
}

sort1 <- function (X, col,DEC=TRUE, ...){
  return(X[sort.list(X[,col], decreasing=DEC), ])
}

matAllCorrs  <- function (X, Y){
  if ((nrow(X)!=nrow(Y))||(ncol(X)!=ncol(Y))) stop('matrices dimensions do not match')
  corrsList<- matrix(NA, nrow=nrow(X), ncol=5)
  colnames(corrsList) <- c("r (Sp)", "r (Pear)", "distCor", "p (Sp)",  "p (Pear)")
  for (i in 1:nrow(X)){
    corrs<- allCorrs(X[i,],Y[i,])
    corrsList[i,] <- corrs
  }
  corrsList<- cbind(corrsList, adj.Spear.Pval= p.adjust(corrsList[,"p (Sp)"],"fdr"))
  corrsList<- cbind(corrsList, adj.Pear.Pval = p.adjust(corrsList[,"p (Pear)"],"fdr"))
  rownames(corrsList) <- rownames(X)
  corrsList <- sort1(corrsList,4, DEC=FALSE)
  return(corrsList)
}

Qnn<-function(x, q) # q: quantil en % (1-100)
{
  x<-as.numeric(x)
  Q<-quantile(x, q/100, na.rm=TRUE)
  return(Q)
}

Initialselection<-function(allData, metilData, corrData,
                           QInf=25, metInf, QSup=75, metSup,
                           Adjust=FALSE, pAdj)
{
  QSupDades<-apply(metilData,1,Qnn, QSup)
  QInfDades<-apply(metilData,1,Qnn, QInf)
  pv<-corrData[,5]
  if (Adjust)   pv<-corrData[,7]
  selCond  <- corrData[ ,2] < 0 &
    pv < pAdj &
    QSupDades > metSup &
    QInfDades < metInf
  Cors <- corrData[selCond,]
  DadesSel <- allData[selCond, ]
  return(DadesSel)
}

Initialselection2<-function(MethData, ExpData, nSI, nID, nSD, met_max, dif_met)
{
  Data<-merge(MethData, ExpData, by=0, all=TRUE)
  rownames(Data)=Data$Row.names
  Data$Row.names<-NULL
  
  splines.table <- matrix(0,nrow = nrow(Data), ncol=7, byrow=F)
  rownames(splines.table) <- rownames(Data)
  colnames(splines.table) <- c("max_met", "max_expr", "dif_met", "nSupI", "nInfD", "nSupD", "meth_regulated")
  splines.table <- as.data.frame(splines.table)
  
  for (i in 1:nrow(Data)){
    splines.table$max_met[i]<- max(as.numeric(Data[i,1:25]))
    splines.table$max_expr[i]<-max(as.numeric(Data[i,25:50]))
    splines.table$dif_met[i]<-(splines.table$max_met[i]) - min(as.numeric(Data[i,1:25]))
  }
  
  for (i in 1:nrow(Data)){
    contador = 0
    dataMeth <- Data[i,1:25]
    dataExp <- Data[i,26:50]
    meth <- as.numeric(dataMeth) < (splines.table$max_met[i]/2)
    #meth <- as.numeric(dataMeth) < 0.66
    #exprs <- as.numeric(dataExp) > mean(as.numeric(dataExp))
    exprs <- as.numeric(dataExp) > (splines.table$max_expr[i]/2)
    for (j in 1:length(meth)){
      if (meth[j]=="TRUE" & exprs[j]=="TRUE"){
        contador=contador+1
      }
      splines.table$nSupI[i]<-contador
    }
  }
  
  for (i in 1:nrow(Data)){
    contador = 0
    dataMeth <- Data[i,1:25]
    dataExp <- Data[i,26:50]
    #meth <- as.numeric(dataMeth) > 0.66
    meth <- as.numeric(dataMeth) > (splines.table$max_met[i]/2)
    #exprs <- as.numeric(dataExp) < mean(as.numeric(dataExp))
    exprs <- as.numeric(dataExp) < (splines.table$max_expr[i]/2)
    for (j in 1:length(meth)){
      if (meth[j]=="TRUE" & exprs[j]=="TRUE"){
        contador=contador+1
      }
      splines.table$nInfD[i]<-contador
    }
  }
  
  for (i in 1:nrow(Data)){
    contador = 0
    dataMeth <- Data[i,1:25]
    dataExp <- Data[i,26:50]
    #meth <- as.numeric(dataMeth) > 0.66
    meth <- as.numeric(dataMeth) > (splines.table$max_met[i]/2)
    #exprs <- as.numeric(dataExp) > mean(as.numeric(dataExp))
    exprs <- as.numeric(dataExp) > (splines.table$max_expr[i]/2)
    for (j in 1:length(meth)){
      if (meth[j]=="TRUE" & exprs[j]=="TRUE"){
        contador=contador+1
      }
      splines.table$nSupD[i]<-contador
    }
  }
  
  for (i in 1:nrow(Data)){
    if (splines.table$nSupI[i] > nSI & 
        splines.table$nInfD[i] > nID & 
        splines.table$nSupD[i] < nSD  &
        splines.table$max_met[i]> met_max & 
        splines.table$dif_met[i]> dif_met)# &
      #mean_exp_left[i]>mean_exp_right)
    {
      splines.table$meth_regulated[i]<-"YES"
    }
    else{
      splines.table$meth_regulated[i]<-"NO"
    }
  }
  
  finales <- row.names(splines.table[splines.table$meth_regulated == "YES",]) 
  
  filtro <- as.matrix(finales)
  rows.to.keep<-which(rownames(Data) %in% filtro)
  Data_corr1 <- Data[rows.to.keep,]
  return(Data_corr1)
}

calculaSplines<-function(mat)
{
  Qmet <- quantile(mat$met, probs=c(0.25,0.5,0.75))
  reg<-lm(expr~bs(met,knots=Qmet, degree=2), data=mat)
  summ<-summary(reg)
  return(summ$coef)
}


plotWithSplines<-function(mat,titleText)
{
  x<-mat[,1]
  y<-mat[,2]
  maxy<-max(y)
  miny<-min(y)
  plot(x,y,  xlim=c(0,1),ylim=c(miny, maxy),main=titleText)
  Qmet<-quantile(x, probs=c(0.25,0.5,0.75))
  reg<-lm(expr~bs(met,knots=Qmet, degree=2), data=mat)
  minval<-min(x)
  maxval<-max(x)
  u<-seq(minval,maxval,by=.1)
  B<-data.frame(met=u)
  Y<-predict(reg,newdata=B)
  lines(u,Y,lwd=2,col="red")
}


PlotAGroup<-function(nameFile, Members, ListGenes)
{
  if (nameFile !="") pdf(nameFile)
  for (IdGene in Members )
  {
    myTitle<-paste("Gene",IdGene, sep=" ")
    mat<-ListGenes[[IdGene]]
    plotWithSplines(mat,myTitle)
  }
  if (nameFile !="") dev.off()
}


#######################
# functions for Shiny #
#######################

cMI_genes <- function(MethData, ExpData, h, r, cMI0){
  
  t <- seq(0,1,by=0.01)
  
  cMI_values <- matrix(0,nrow = nrow(ExpData), ncol = length(t)+4, byrow = TRUE)
  rownames(cMI_values) <- rownames(ExpData)
  colnames(cMI_values) <- c(t,"cMI_min", "t_opt", "r", "meth_regulated")
  
  # compute cMI for each t-value
  for (i in 1:nrow(MethData)){ 
    dataMeth <- as.numeric(MethData[i,])
    dataExp <- as.numeric(ExpData[i,])
    for (j in 1:length(t)){
      cMI_values[i,j] <- cMI(dataMeth,dataExp,t[j],h)
    }
  }
  
  # minimum cMI
  for (i in 1:nrow(cMI_values)){
    col <- length(t)+1
    cMI_values[i,col] <- min(cMI_values[i,1:col-1])
  }
  
  # t-value for minimum cMI (t_opt)
  for (i in 1:nrow(cMI_values)){ 
    cMI_values[i,col+1] <- as.numeric(names(which.min(cMI_values[i,1:col])))
  }
  
  # 1st condition: r = min{cMI(t)} /cMI(0) must be "small enough"
  for (i in 1:nrow(cMI_values)){ 
    cMI_values[i,col+2] <- cMI_values[i,col]/cMI_values[i,1]
  }
  
  # 3rd condition: values at left side must be higher than values at right side
  mean_exp_left <- c()
  mean_exp_right <- c()
  for (i in 1:nrow(cMI_values)){ 
    dataMeth <- as.numeric(MethData[i,])
    dataExp <- as.numeric(ExpData[i,])
    # filter data < optimal threshold
    filt <- dataMeth < cMI_values[i,col+1]
    left <- dataExp[!filt]
    right <- dataExp[filt]
    if (sum(left) == 0){
      mean_exp_left[i] <- 0
      mean_exp_right[i] <- mean(right)
    }
    if (sum(right) == 0){
      mean_exp_right[i] <- 0
      mean_exp_left[i] <- mean(left)
    }
    else{
      mean_exp_left[i] <- mean(left)
      mean_exp_right[i] <- mean(right)
    }
  }
  
  for (i in 1:nrow(MethData)){
    if (cMI_values[i,col+2] < r & 
        cMI_values[i,1] > cMI0 & 
        mean_exp_left[i] > mean_exp_right[i]){
      cMI_values[i,col+3] <- "YES"
    }
    else{
      cMI_values[i,col+3] <- "NO"
    }
  }
  cMI_values<-as.data.frame(cMI_values)
  selected <- row.names(cMI_values[cMI_values$meth_regulated == "YES",])
  selected<- as.data.frame(selected)
  return(selected)
}


##B-Splines
splines_genes <-function(MethData, ExpData, nSI, nID, nSD, met_max, dif_met) {
  
  Data<-merge(MethData, ExpData, by=0, all=TRUE)
  rownames(Data)=Data$Row.names
  Data$Row.names<-NULL
  
  splines.table <- matrix(0,nrow = nrow(Data), ncol=7, byrow=F)
  rownames(splines.table) <- rownames(Data)
  colnames(splines.table) <- c("max_met", "max_expr", "dif_met", "nSupI", "nInfD", "nSupD", "meth_regulated")
  splines.table <- as.data.frame(splines.table)
  
  for (i in 1:nrow(Data)){
    splines.table$max_met[i]<- max(as.numeric(Data[i,1:25]))
    splines.table$max_expr[i]<-max(as.numeric(Data[i,25:50]))
    splines.table$dif_met[i]<-(splines.table$max_met[i]) - min(as.numeric(Data[i,1:25]))
  }
  
  for (i in 1:nrow(Data)){
    contador = 0
    dataMeth <- Data[i,1:25]
    dataExp <- Data[i,26:50]
    meth <- as.numeric(dataMeth) < (splines.table$max_met[i]/2)
    #meth <- as.numeric(dataMeth) < 0.66
    #exprs <- as.numeric(dataExp) > mean(as.numeric(dataExp))
    exprs <- as.numeric(dataExp) > (splines.table$max_expr[i]/2)
    for (j in 1:length(meth)){
      if (meth[j]=="TRUE" & exprs[j]=="TRUE"){
        contador=contador+1
      }
      splines.table$nSupI[i]<-contador
    }
  }
  
  for (i in 1:nrow(Data)){
    contador = 0
    dataMeth <- Data[i,1:25]
    dataExp <- Data[i,26:50]
    #meth <- as.numeric(dataMeth) > 0.66
    meth <- as.numeric(dataMeth) > (splines.table$max_met[i]/2)
    #exprs <- as.numeric(dataExp) < mean(as.numeric(dataExp))
    exprs <- as.numeric(dataExp) < (splines.table$max_expr[i]/2)
    for (j in 1:length(meth)){
      if (meth[j]=="TRUE" & exprs[j]=="TRUE"){
        contador=contador+1
      }
      splines.table$nInfD[i]<-contador
    }
  }
  
  for (i in 1:nrow(Data)){
    contador = 0
    dataMeth <- Data[i,1:25]
    dataExp <- Data[i,26:50]
    #meth <- as.numeric(dataMeth) > 0.66
    meth <- as.numeric(dataMeth) > (splines.table$max_met[i]/2)
    #exprs <- as.numeric(dataExp) > mean(as.numeric(dataExp))
    exprs <- as.numeric(dataExp) > (splines.table$max_expr[i]/2)
    for (j in 1:length(meth)){
      if (meth[j]=="TRUE" & exprs[j]=="TRUE"){
        contador=contador+1
      }
      splines.table$nSupD[i]<-contador
    }
  }
  
  for (i in 1:nrow(Data)){
    if (splines.table$nSupI[i] > nSI & 
        splines.table$nInfD[i] > nID & 
        splines.table$nSupD[i] < nSD  &
        splines.table$max_met[i]> met_max & 
        splines.table$dif_met[i]> dif_met)# &
      #mean_exp_left[i]>mean_exp_right)
    {
      splines.table$meth_regulated[i]<-"YES"
    }
    else{
      splines.table$meth_regulated[i]<-"NO"
    }
  }
  selected <- row.names(splines.table[splines.table$meth_regulated == "YES",])
  selected<- as.data.frame(selected)
  return(selected)
}


