## ---- warning = FALSE, message = FALSE-----------------------------------
library(lpattern)

## ------------------------------------------------------------------------
load("ExpData.rda")
load("MethData.rda")

## ------------------------------------------------------------------------
t <- seq(0,1,by=0.01)

cMI_values <- matrix(NA,nrow = nrow(ExpData), 
              ncol = length(t)+4, 
              byrow = TRUE)
rownames(cMI_values) <- rownames(ExpData)
colnames(cMI_values) <- c(t,"cMI_min", "t_opt", "r",
                          "meth_regulated")
cMI_values <- as.data.frame(cMI_values)

## ------------------------------------------------------------------------
for (i in 1:nrow(MethData)){ 
  dataMeth <- MethData[i,]
  dataExp <- ExpData[i,]
  for (j in 1:length(t)){
    cMI_values[i,j] <- cMI(dataMeth,dataExp,t[j],h=0.2)
    }
  }

## ------------------------------------------------------------------------
for (i in 1:nrow(cMI_values)){
  cMI_values$cMI_min[i] <- min(cMI_values[i,1:length(t)])
}

for (i in 1:nrow(cMI_values)){ 
  cMI_values$t_opt[i] <- names(which.min(cMI_values[i,1:length(t)]))
}

## ------------------------------------------------------------------------
for (i in 1:nrow(cMI_values)){ 
    cMI_values$r[i] <- cMI_values$cMI_min[i]/cMI_values[i,1]
}

mean_exp_left <- c()
mean_exp_right <- c()
for (i in 1:nrow(cMI_values)){ 
  dataMeth <- MethData[i,]
  dataExp <- ExpData[i,]
  filt <- dataMeth <= cMI_values$t_opt[i]
  right <- dataExp[!filt]
  left <- dataExp[filt]
  if (sum(left) == 0){
    mean_exp_left[i] <- 0
    mean_exp_right[i] <- mean(right)
  }
  if (sum(right) == 0){
    mean_exp_right[i] <- 0
    mean_exp_left[i] <- mean(left)
  }
  else{
    mean_exp_left[i] <- mean(left)
    mean_exp_right[i] <- mean(right)
  }
}

## ------------------------------------------------------------------------
for (i in 1:nrow(MethData)){
  if (cMI_values$r[i] < 0.25 & 
      cMI_values[i,1] > 0.1 & 
      mean_exp_left[i] > mean_exp_right[i]){
    cMI_values$meth_regulated[i] <- "YES"
  }
  else{
    cMI_values$meth_regulated[i] <- "NO"
  }
}

## ---- echo=FALSE---------------------------------------------------------
sum(cMI_values$r < 0.25)

## ---- echo=FALSE---------------------------------------------------------
sum((cMI_values$r < 0.25) & (cMI_values[,1] > 0.1))

## ---- echo=FALSE---------------------------------------------------------
sum(cMI_values$meth_regulated=="YES")

## ------------------------------------------------------------------------
write.csv(row.names(cMI_values[cMI_values$meth_regulated == "YES",]),
          "cMI_genes.csv", row.names=FALSE)

## ------------------------------------------------------------------------
pdf("CMI_plots.pdf")
for (i in 1:nrow(cMI_values)){
  if(cMI_values$meth_regulated[i] == "YES"){
    x <- as.numeric(MethData[i,])
    y <- as.numeric(ExpData[i,])
    plot(x,y,xlim=c(0,1), ylim=c(min(ExpData[i,]),
                                 max(ExpData[i,])),main=row.names(MethData[i,]))
  }}
dev.off()

## ------------------------------------------------------------------------
load("ExpData.rda")
load("MethData.rda")

## ------------------------------------------------------------------------
Data_corr1<-Initialselection2(MethData, ExpData, 
                              nSI=3, nID=2, nSD=1, 
                              met_max=0.05, dif_met=0.35)
genes.sel.Splines<-row.names(Data_corr1)
write.csv(genes.sel.Splines, quote=FALSE, row.names=FALSE, file="genesSelSplines.csv")

## ---- echo=FALSE---------------------------------------------------------
length(genes.sel.Splines)

## ---- echo=FALSE---------------------------------------------------------
cat((nrow(MethData)-length(genes.sel.Splines)), "genes removed")
cat((((nrow(MethData)-length(genes.sel.Splines))/nrow(MethData))*100), 
    "% genes removed")

## ------------------------------------------------------------------------
ngenesCor <- dim(Data_corr1)[1]
ListGenes <- list()
for (i in 1:ngenesCor){
  x<-as.numeric(Data_corr1[i,1:25])
  y<-as.numeric(Data_corr1[i,26:50])
  Data_gene<-na.omit(data.frame(met=x,expr=y))
  ListGenes[[i]]<-Data_gene
}
namesGenesCor <- row.names(Data_corr1)
names(ListGenes)<-as.character(namesGenesCor)

ListSplines <- list()
ListSplines<-lapply(ListGenes, calculaSplines)
names(ListSplines) <- namesGenesCor

Data_cluster  <- matrix(0, nrow=ngenesCor, ncol=6)
for(i in 1:ngenesCor) Data_cluster[i,] <- ListSplines[[i]][,1]
colnames(Data_cluster) <- c("interc", "coef1", "coef2","coef3","coef4","coef5")
row.names(Data_cluster) <- namesGenesCor

## ---- echo=FALSE---------------------------------------------------------
opt<-par(mfrow=c(1,1))
wss <- (nrow(Data_cluster)-1)*sum(apply(Data_cluster,2,var)) 
for (i in 2:10) 
{km<-kmeans(Data_cluster, centers=i)
wss[i] <- km$tot.withinss
}
plot(1:10, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")

## ---- echo=FALSE---------------------------------------------------------
matDist<-as.dist(1-cor(t(Data_cluster)))
Hcluster<-hclust(matDist, method="average")
plot(Hcluster, main="cluster of coefficients")

## ---- echo=FALSE---------------------------------------------------------
Hclustgroups0.55<- cutree(Hcluster, h=0.55) 
table(Hclustgroups0.55) 
Hclustgroups<-Hclustgroups0.55
nclusters<-dim(table(Hclustgroups))
names(Hclustgroups)<-row.names(Data_cluster)

genesInClusters<-list()
for (i in 1:nclusters)
{
  genesInClusters[[i]]<-names(Hclustgroups[Hclustgroups==i])
}
Data_with_cluster<-cbind(Data_corr1, Hclustgroups)

## ------------------------------------------------------------------------
MeanPattern<-NULL
MedianPattern<-NULL
mymean<-function(x) {mean(x, na.rm=TRUE)}
for (i in 1:nclusters)
{
  D<-Data_corr1[Hclustgroups==i,]
  DMedian<-apply(D,2,Qnn,50)
  DMean<-apply(D,2,mymean)
  MeanPattern<-rbind(MeanPattern,DMean)
  MedianPattern<-rbind(MedianPattern,DMedian)
}
ListMeanPatterns <- list()
for (i in 1:nclusters)
{
  x<-as.numeric(MeanPattern[i,1:25])
  y<-as.numeric(MeanPattern[i,26:50])
  DadesPattern<-na.omit(data.frame(met=x,expr=y))
  ListMeanPatterns[[i]]<-DadesPattern
}
ListMedianPatterns <- list()
for (i in 1:nclusters)
{
  x<-as.numeric(MedianPattern[i,1:25])
  y<-as.numeric(MedianPattern[i,26:50])
  DadesPattern<-na.omit(data.frame(met=x,expr=y))
  ListMedianPatterns[[i]]<-DadesPattern
}
opt<-par(mfrow=c(3,3), pty="m", oma=c(0,0,2,0), mar=c(5,4,2,2), font.main=1)
toPDF <- FALSE 
if (toPDF) {
  nameFile<-paste("/PatternsMetExpr",".pdf", sep="")  
  pdf(nameFile)
}
opt<-par(mfrow=c(3,2), pty="m", oma=c(0,0,2,0), mar=c(5,4,2,2), font.main=1)
for (i in 1:nclusters)
{
  myTitle<-paste("pattern",i, sep=" ")
  mat<-ListMeanPatterns[[i]]
  plotWithSplines(mat,myTitle)
}
opt<-par(mfrow=c(3,2), pty="m", oma=c(0,0,2,0), mar=c(5,4,2,2), font.main=1)
for (i in 1:nclusters)
{
  myTitle<-paste("pattern",i, sep=" ")
  mat<-ListMedianPatterns[[i]]
  plotWithSplines(mat,myTitle)
}
if (toPDF) dev.off()

## ---- echo=FALSE---------------------------------------------------------
for (i in 1:nclusters)
{
  nFile<-paste("Spline_genes_cluster",i,".pdf", sep="")  
  GInCluster<-names(Hclustgroups[Hclustgroups==i])
  PlotAGroup(nFile,GInCluster,ListGenes)
}

## ------------------------------------------------------------------------
write.csv(genes.sel.Splines, quote=FALSE, row.names=FALSE, file="Spline_genes.csv")

## ---- echo=FALSE, message=FALSE------------------------------------------
CMI.genes <- rownames(subset(cMI_values, cMI_values$meth_regulated=="YES"))
splines.genes <- rownames(Data_corr1)
area1=length(CMI.genes)
area2=length(splines.genes)
n12=length(intersect(CMI.genes, splines.genes))
draw.pairwise.venn(area1, area2, n12, category = c("CMI", "Splines"), 
                   lty = "blank", fill = c("skyblue", "pink1"))

## ---- echo=FALSE, message=FALSE------------------------------------------
intersect(CMI.genes, splines.genes)

